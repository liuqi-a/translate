// src/shared/settings.ts
var storageKey = "moyeSettings";
var defaultSettings = {
  apiKey: "",
  baseUrl: "https://api.deepseek.com",
  model: "deepseek-flash",
  direction: "en-zh"
};
function isRecord(value) {
  return typeof value === "object" && value !== null;
}
function isDirection(value) {
  return value === "en-zh" || value === "zh-en" || value === "auto";
}
function normalizeSettings(value) {
  const source = isRecord(value) ? value : {};
  const baseUrl = typeof source.baseUrl === "string" ? source.baseUrl.trim() : "";
  const model = typeof source.model === "string" ? source.model.trim() : "";
  return {
    apiKey: typeof source.apiKey === "string" ? source.apiKey : "",
    baseUrl: baseUrl || defaultSettings.baseUrl,
    model: model || defaultSettings.model,
    direction: isDirection(source.direction) ? source.direction : defaultSettings.direction
  };
}
async function readSettings() {
  const stored = await chrome.storage.local.get(storageKey);
  return normalizeSettings(stored[storageKey]);
}
function errorMessage(error) {
  if (error instanceof Error && error.message) return error.message;
  if (typeof error === "string" && error) return error;
  return "\u51FA\u73B0\u672A\u77E5\u9519\u8BEF";
}

// src/background/serviceWorker.ts
function isRecord2(value) {
  return typeof value === "object" && value !== null;
}
function isTarget(value) {
  return value === "\u4E2D\u6587" || value === "\u82F1\u6587";
}
function endpointCandidates(baseUrl) {
  const trimmed = baseUrl.trim().replace(/\/+$/, "");
  if (!/^https?:\/\/.+/i.test(trimmed)) {
    throw new Error("Base URL \u9700\u8981\u4EE5 http:// \u6216 https:// \u5F00\u5934");
  }
  if (/\/chat\/completions$/i.test(trimmed)) return [trimmed];
  if (/\/v\d+$/i.test(trimmed)) return [`${trimmed}/chat/completions`];
  return [`${trimmed}/chat/completions`, `${trimmed}/v1/chat/completions`];
}
function ensureSettings(settings) {
  if (!settings.apiKey.trim()) throw new Error("\u8BF7\u5148\u586B\u5199 API Key");
  endpointCandidates(settings.baseUrl);
}
function readError(raw) {
  try {
    const parsed = JSON.parse(raw);
    if (parsed.error?.message) return parsed.error.message;
  } catch {
  }
  return raw.replace(/\s+/g, " ").slice(0, 240);
}
function stripFence(raw) {
  const trimmed = raw.trim();
  const fenced = /^```(?:json)?\s*([\s\S]*?)\s*```$/i.exec(trimmed);
  return fenced?.[1]?.trim() ?? trimmed;
}
function parseJsonValue(raw) {
  const trimmed = stripFence(raw);
  try {
    return JSON.parse(trimmed);
  } catch {
    const start = trimmed.search(/[\[{]/);
    const end = Math.max(trimmed.lastIndexOf("}"), trimmed.lastIndexOf("]"));
    if (start >= 0 && end > start) return JSON.parse(trimmed.slice(start, end + 1));
    throw new Error("\u6A21\u578B\u8FD4\u56DE\u7684\u4E0D\u662F\u5408\u6CD5 JSON");
  }
}
async function postChat(url, settings, messages, jsonMode, maxTokens, extra) {
  const body = {
    model: settings.model.trim() || defaultSettings.model,
    messages,
    temperature: 0.2,
    max_tokens: maxTokens,
    stream: false
  };
  if (extra) {
    body.thinking = { type: "disabled" };
    if (jsonMode) body.response_format = { type: "json_object" };
  }
  let response;
  try {
    response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${settings.apiKey.trim()}`
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(9e4)
    });
  } catch (error) {
    throw new Error(`\u7F51\u7EDC\u8BF7\u6C42\u5931\u8D25\uFF1A${errorMessage(error)}`);
  }
  const raw = await response.text();
  if (!response.ok) throw new Error(`\u63A5\u53E3\u9519\u8BEF ${response.status}\uFF1A${readError(raw)}`);
  let data;
  try {
    data = JSON.parse(raw);
  } catch {
    throw new Error("\u6A21\u578B\u8FD4\u56DE\u7684\u4E0D\u662F\u5408\u6CD5 JSON");
  }
  const choice = data.choices?.[0];
  if (choice?.finish_reason === "length") throw new Error("\u7FFB\u8BD1\u7ED3\u679C\u957F\u5EA6\u4E0D\u5339\u914D\uFF1A\u8F93\u51FA\u88AB\u622A\u65AD");
  const content = choice?.message?.content;
  if (typeof content !== "string" || !content.trim()) throw new Error("\u63A5\u53E3\u672A\u8FD4\u56DE\u6587\u672C");
  return { content, model: data.model || settings.model };
}
async function completeOnce(settings, messages, jsonMode, maxTokens) {
  ensureSettings(settings);
  const urls = endpointCandidates(settings.baseUrl);
  let lastError;
  for (const url of urls) {
    try {
      return await postChat(url, settings, messages, jsonMode, maxTokens, true);
    } catch (error) {
      lastError = error;
      const message = errorMessage(error);
      if (message.includes("400") || message.includes("422")) {
        try {
          return await postChat(url, settings, messages, false, maxTokens, false);
        } catch (inner) {
          lastError = inner;
        }
      }
      if (message.includes("404") || message.includes("405") || message.includes("\u7F51\u7EDC\u8BF7\u6C42\u5931\u8D25")) continue;
      break;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("\u8BF7\u6C42\u5931\u8D25");
}
async function complete(settings, messages, jsonMode, maxTokens) {
  try {
    return await completeOnce(settings, messages, jsonMode, maxTokens);
  } catch (error) {
    if (!errorMessage(error).includes("\u7F51\u7EDC\u8BF7\u6C42\u5931\u8D25")) throw error;
    return completeOnce(settings, messages, jsonMode, maxTokens);
  }
}
function translateMessages(texts, target) {
  return [
    {
      role: "system",
      content: '\u4F60\u662F\u7FFB\u8BD1\u5F15\u64CE\u3002\u53EA\u8F93\u51FA JSON \u5BF9\u8C61 {"items": string[]}\uFF0C\u4E0D\u8981 Markdown\uFF0C\u4E0D\u8981\u89E3\u91CA\u3002'
    },
    {
      role: "user",
      content: `\u628A items \u4E2D\u6BCF\u6761\u6587\u672C\u7FFB\u8BD1\u6210${target}\u3002\u6570\u7EC4\u957F\u5EA6\u548C\u987A\u5E8F\u5FC5\u987B\u4E0D\u53D8\u3002\u4FDD\u7559\u6570\u5B57\u3001\u4E13\u540D\u3001URL\u3001\u90AE\u7BB1\u3001\u4EE3\u7801\u548C\u5360\u4F4D\u7B26\u3002
${JSON.stringify({ items: texts })}`
    }
  ];
}
async function translateBatch(texts, target) {
  const settings = await readSettings();
  const result = await complete(settings, translateMessages(texts, target), true, 4096);
  const parsed = parseJsonValue(result.content);
  const source = Array.isArray(parsed) ? parsed : isRecord2(parsed) ? parsed.items ?? parsed.translations : void 0;
  if (!Array.isArray(source)) throw new Error("\u6A21\u578B\u8FD4\u56DE\u7684\u4E0D\u662F\u5408\u6CD5 JSON");
  if (source.length !== texts.length) {
    throw new Error(`\u7FFB\u8BD1\u7ED3\u679C\u957F\u5EA6\u4E0D\u5339\u914D\uFF1A\u671F\u671B ${texts.length} \u5B9E\u9645 ${source.length}`);
  }
  return source.map((item) => typeof item === "string" ? item : String(item ?? ""));
}
function summaryMessages(text, target) {
  return [
    {
      role: "system",
      content: '\u4F60\u662F\u7F51\u9875\u6458\u8981\u52A9\u624B\u3002\u53EA\u8F93\u51FA JSON\uFF1A{"title": string, "overview": string, "points": string[]}\u3002\u4E0D\u8981\u7F16\u9020\u6B63\u6587\u6CA1\u6709\u7684\u4E8B\u5B9E\u3002'
    },
    {
      role: "user",
      content: `\u7528${target}\u603B\u7ED3\u4E0B\u9762\u7684\u7F51\u9875\u6B63\u6587\u3002overview \u7528\u4E00\u53E5\u8BDD\uFF0Cpoints \u5199 4 \u5230 6 \u6761\uFF0C\u6BCF\u6761\u4E0D\u8D85\u8FC7 40 \u5B57\u3002

${text}`
    }
  ];
}
async function summarize(text, target) {
  const settings = await readSettings();
  const result = await complete(settings, summaryMessages(text, target), true, 1200);
  const parsed = parseJsonValue(result.content);
  if (!isRecord2(parsed)) throw new Error("\u6A21\u578B\u8FD4\u56DE\u7684\u4E0D\u662F\u5408\u6CD5 JSON");
  const points = Array.isArray(parsed.points) ? parsed.points.map((item) => String(item).trim()).filter(Boolean) : [];
  const overview = typeof parsed.overview === "string" ? parsed.overview.trim() : "";
  const title = typeof parsed.title === "string" && parsed.title.trim() ? parsed.title.trim() : "\u9875\u9762\u603B\u7ED3";
  if (!overview && points.length === 0) throw new Error("\u603B\u7ED3\u5185\u5BB9\u4E3A\u7A7A");
  return { title, overview, points };
}
async function testConnection(settings) {
  const result = await complete(
    settings,
    [{ role: "user", content: "\u53EA\u56DE\u590D\u5C0F\u5199\u5355\u8BCD pong" }],
    false,
    32
  );
  return result.model;
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!isRecord2(message) || typeof message.type !== "string") return false;
  if (message.type === "translate-batch") {
    const texts = message.texts;
    if (!Array.isArray(texts) || texts.some((item) => typeof item !== "string") || !isTarget(message.target)) {
      sendResponse({ ok: false, error: "\u7FFB\u8BD1\u53C2\u6570\u65E0\u6548" });
      return true;
    }
    void translateBatch(texts, message.target).then((items) => sendResponse({ ok: true, texts: items })).catch((error) => sendResponse({ ok: false, error: errorMessage(error) }));
    return true;
  }
  if (message.type === "summarize") {
    if (typeof message.text !== "string" || !isTarget(message.target)) {
      sendResponse({ ok: false, error: "\u603B\u7ED3\u53C2\u6570\u65E0\u6548" });
      return true;
    }
    void summarize(message.text, message.target).then((summary) => sendResponse({ ok: true, summary })).catch((error) => sendResponse({ ok: false, error: errorMessage(error) }));
    return true;
  }
  if (message.type === "test-connection") {
    const settings = normalizeSettings(message.settings);
    void testConnection(settings).then((model) => sendResponse({ ok: true, model, message: "\u8FDE\u63A5\u6210\u529F" })).catch((error) => sendResponse({ ok: false, error: errorMessage(error) }));
    return true;
  }
  return false;
});
