"use strict";
(() => {
  // src/shared/settings.ts
  var storageKey = "moyeSettings";
  var defaultSettings = {
    apiKey: "",
    baseUrl: "https://api.deepseek.com",
    model: "deepseek-flash",
    direction: "en-zh"
  };
  function isRecord(value) {
    return typeof value === "object" && value !== null;
  }
  function isDirection(value) {
    return value === "en-zh" || value === "zh-en" || value === "auto";
  }
  function normalizeSettings(value) {
    const source = isRecord(value) ? value : {};
    const baseUrl = typeof source.baseUrl === "string" ? source.baseUrl.trim() : "";
    const model = typeof source.model === "string" ? source.model.trim() : "";
    return {
      apiKey: typeof source.apiKey === "string" ? source.apiKey : "",
      baseUrl: baseUrl || defaultSettings.baseUrl,
      model: model || defaultSettings.model,
      direction: isDirection(source.direction) ? source.direction : defaultSettings.direction
    };
  }
  async function readSettings() {
    const stored = await chrome.storage.local.get(storageKey);
    return normalizeSettings(stored[storageKey]);
  }
  async function writeSettings(settings) {
    await chrome.storage.local.set({ [storageKey]: normalizeSettings(settings) });
  }
  function errorMessage(error) {
    if (error instanceof Error && error.message) return error.message;
    if (typeof error === "string" && error) return error;
    return "\u51FA\u73B0\u672A\u77E5\u9519\u8BEF";
  }

  // src/popup/popup.ts
  function byId(id) {
    const element = document.getElementById(id);
    if (!element) throw new Error(`\u7F3A\u5C11\u8282\u70B9 ${id}`);
    return element;
  }
  var apiKeyInput = byId("apiKey");
  var baseUrlInput = byId("baseUrl");
  var modelInput = byId("model");
  var statusNode = byId("status");
  var dot = byId("dot");
  var form = byId("settingsForm");
  var toggleKeyButton = byId("toggleKey");
  var testButton = byId("test");
  var translateButton = byId("translate");
  var summarizeButton = byId("summarize");
  var restoreButton = byId("restore");
  var directionButtons = [...document.querySelectorAll("[data-direction]")];
  var actionButtons = [translateButton, summarizeButton, restoreButton, testButton];
  var direction = "en-zh";
  function setStatus(text, tone) {
    statusNode.textContent = text;
    statusNode.className = tone;
    dot.className = tone ? `dot ${tone}` : "dot";
  }
  function setDirection(next) {
    direction = next;
    for (const button of directionButtons) {
      button.classList.toggle("active", button.dataset.direction === next);
    }
  }
  function setBusy(busy) {
    for (const button of actionButtons) button.disabled = busy;
  }
  async function persistForm() {
    const settings = normalizeSettings({
      apiKey: apiKeyInput.value,
      baseUrl: baseUrlInput.value,
      model: modelInput.value,
      direction
    });
    if (!/^https?:\/\/.+/i.test(settings.baseUrl)) {
      throw new Error("Base URL \u9700\u8981\u4EE5 http:// \u6216 https:// \u5F00\u5934");
    }
    await writeSettings(settings);
    baseUrlInput.value = settings.baseUrl;
    modelInput.value = settings.model;
    return settings;
  }
  async function findWebTab() {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const active = tabs.find((tab) => tab.active && !!tab.url && /^https?:/i.test(tab.url));
    if (active) return active;
    return tabs.find((tab) => !!tab.url && /^https?:/i.test(tab.url));
  }
  async function sendToPage(message) {
    const tab = await findWebTab();
    if (!tab?.id) throw new Error("\u8BF7\u5148\u6253\u5F00\u4E00\u4E2A\u666E\u901A\u7F51\u9875");
    try {
      return await chrome.tabs.sendMessage(tab.id, message);
    } catch {
      try {
        await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
        return await chrome.tabs.sendMessage(tab.id, message);
      } catch {
        throw new Error("\u65E0\u6CD5\u5728\u6B64\u9875\u9762\u8FD0\u884C\uFF0C\u8BF7\u6362\u4E00\u4E2A\u666E\u901A\u7F51\u9875");
      }
    }
  }
  async function runPageAction(type, pending) {
    setBusy(true);
    setStatus(pending, "busy");
    try {
      await persistForm();
      const result = await sendToPage({ type });
      if (!result?.ok) throw new Error(result?.error || "\u64CD\u4F5C\u5931\u8D25");
      setStatus(result.message || "\u5DF2\u5B8C\u6210", "ok");
    } catch (error) {
      setStatus(errorMessage(error), "error");
    } finally {
      setBusy(false);
    }
  }
  async function testConnection() {
    setBusy(true);
    setStatus("\u6B63\u5728\u8FDE\u63A5\u2026", "busy");
    try {
      const settings = await persistForm();
      const result = await chrome.runtime.sendMessage({
        type: "test-connection",
        settings
      });
      if (!result?.ok) throw new Error(result?.error || "\u8FDE\u63A5\u5931\u8D25");
      setStatus(`\u8FDE\u63A5\u6210\u529F \xB7 ${result.model || settings.model}`, "ok");
    } catch (error) {
      setStatus(errorMessage(error), "error");
    } finally {
      setBusy(false);
    }
  }
  async function loadForm() {
    const settings = await readSettings();
    apiKeyInput.value = settings.apiKey;
    baseUrlInput.value = settings.baseUrl;
    modelInput.value = settings.model;
    setDirection(settings.direction);
  }
  for (const button of directionButtons) {
    button.addEventListener("click", () => {
      const value = button.dataset.direction;
      if (isDirection(value)) setDirection(value);
    });
  }
  toggleKeyButton.addEventListener("click", () => {
    const visible = apiKeyInput.type === "text";
    apiKeyInput.type = visible ? "password" : "text";
    toggleKeyButton.textContent = visible ? "\u663E\u793A" : "\u9690\u85CF";
  });
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    void (async () => {
      try {
        await persistForm();
        setStatus("\u8BBE\u7F6E\u5DF2\u4FDD\u5B58", "ok");
      } catch (error) {
        setStatus(errorMessage(error), "error");
      }
    })();
  });
  testButton.addEventListener("click", () => {
    void testConnection();
  });
  translateButton.addEventListener("click", () => {
    void runPageAction("translate-page", "\u6B63\u5728\u7FFB\u8BD1\u5F53\u524D\u9875\u9762\u2026");
  });
  summarizeButton.addEventListener("click", () => {
    void runPageAction("summarize-page", "\u6B63\u5728\u603B\u7ED3\u6B64\u9875\u2026");
  });
  restoreButton.addEventListener("click", () => {
    void runPageAction("restore-page", "\u6B63\u5728\u6062\u590D\u539F\u6587\u2026");
  });
  void loadForm();
})();
