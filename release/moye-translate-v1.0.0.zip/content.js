"use strict";
(() => {
  // src/shared/settings.ts
  var storageKey = "moyeSettings";
  var defaultSettings = {
    apiKey: "",
    baseUrl: "https://api.deepseek.com",
    model: "deepseek-flash",
    direction: "en-zh"
  };
  function isRecord(value) {
    return typeof value === "object" && value !== null;
  }
  function isDirection(value) {
    return value === "en-zh" || value === "zh-en" || value === "auto";
  }
  function normalizeSettings(value) {
    const source = isRecord(value) ? value : {};
    const baseUrl = typeof source.baseUrl === "string" ? source.baseUrl.trim() : "";
    const model = typeof source.model === "string" ? source.model.trim() : "";
    return {
      apiKey: typeof source.apiKey === "string" ? source.apiKey : "",
      baseUrl: baseUrl || defaultSettings.baseUrl,
      model: model || defaultSettings.model,
      direction: isDirection(source.direction) ? source.direction : defaultSettings.direction
    };
  }
  async function readSettings() {
    const stored = await chrome.storage.local.get(storageKey);
    return normalizeSettings(stored[storageKey]);
  }
  function errorMessage(error) {
    if (error instanceof Error && error.message) return error.message;
    if (typeof error === "string" && error) return error;
    return "\u51FA\u73B0\u672A\u77E5\u9519\u8BEF";
  }

  // src/content/content.ts
  var skipSelector = "script,style,noscript,code,pre,kbd,samp,textarea,svg,canvas,iframe,[data-moye-root]";
  var overlayCss = `
  * { box-sizing: border-box; }
  .hidden { display: none !important; }
  .dock, .bubble, .summary {
    position: fixed;
    z-index: 2147483646;
    color: #1d1a16;
    font: 13px/1.5 "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
  }
  .dock {
    left: 50%;
    bottom: 18px;
    transform: translateX(-50%);
    display: flex;
    align-items: center;
    gap: 8px;
    max-width: min(560px, calc(100vw - 24px));
    padding: 8px 8px 8px 14px;
    border: 1px solid #e4d9c8;
    border-radius: 999px;
    background: #fffdf8;
    box-shadow: 0 12px 32px rgba(40, 24, 16, 0.14);
  }
  .dock span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .bubble {
    width: 280px;
    padding: 12px;
    border: 1px solid #e4d9c8;
    border-radius: 16px;
    background: #fffdf8;
    box-shadow: 0 16px 40px rgba(40, 24, 16, 0.16);
  }
  .summary {
    top: 16px;
    right: 16px;
    width: min(360px, calc(100vw - 32px));
    max-height: calc(100vh - 32px);
    overflow: auto;
    padding: 16px;
    border: 1px solid #e4d9c8;
    border-radius: 18px;
    background: #fffdf8;
    box-shadow: 0 18px 50px rgba(40, 24, 16, 0.16);
  }
  .kicker { color: #a33b32; font-size: 12px; letter-spacing: 0.06em; }
  .source { margin: 8px 0; color: #6f675e; }
  .result, .moye-overview { margin: 8px 0 0; font-size: 14px; white-space: pre-wrap; }
  .summary h2 { margin: 0; font-size: 16px; }
  .summary-head, .summary-top { display: flex; align-items: flex-start; justify-content: space-between; gap: 8px; }
  .summary ul { margin: 8px 0 0; padding-left: 18px; }
  .summary li + li { margin-top: 4px; }
  .danger { color: #a33b32; }
  button {
    height: 30px;
    border: 1px solid #e4d9c8;
    border-radius: 999px;
    background: #fff;
    color: #1d1a16;
    font: inherit;
    padding: 0 12px;
    cursor: pointer;
  }
  button.primary { border-color: transparent; background: #a33b32; color: #fffaf6; }
  button:disabled { opacity: 0.6; cursor: default; }
`;
  var textRecords = [];
  var attrRecords = [];
  var translatedText = /* @__PURE__ */ new WeakSet();
  var translatedAttrs = /* @__PURE__ */ new WeakMap();
  var jobToken = 0;
  var host;
  var shadow;
  var dock;
  var bubble;
  var summary;
  function start() {
    if (window.__moyeLoaded) return;
    mountOverlay();
    window.__moyeLoaded = true;
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      void dispatchPageMessage(message, sendResponse);
      return isPageMessage(message);
    });
    document.addEventListener("mouseup", onMouseUp);
    document.addEventListener("mousedown", onMouseDown);
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        hideBubble();
        hideSummary();
      }
    });
  }
  function isPageMessage(message) {
    if (!message || typeof message !== "object") return false;
    const type = message.type;
    return type === "translate-page" || type === "summarize-page" || type === "restore-page";
  }
  async function dispatchPageMessage(message, sendResponse) {
    if (!isPageMessage(message)) return;
    const type = message.type;
    try {
      if (type === "translate-page") {
        reply(sendResponse, await translatePage());
        return;
      }
      if (type === "summarize-page") {
        reply(sendResponse, await summarizePage());
        return;
      }
      reply(sendResponse, restorePage());
    } catch (error) {
      reply(sendResponse, { ok: false, error: errorMessage(error) });
    }
  }
  function reply(sendResponse, result) {
    try {
      sendResponse(result);
    } catch {
    }
  }
  async function translatePage() {
    const token = ++jobToken;
    const settings = await readSettings();
    const items = collectWork(settings.direction);
    if (items.length === 0) {
      showDock("\u6CA1\u6709\u9700\u8981\u7FFB\u8BD1\u7684\u6587\u672C", [{ label: "\u5173\u95ED", onClick: hideDock }]);
      return { ok: true, message: "\u6CA1\u6709\u9700\u8981\u7FFB\u8BD1\u7684\u6587\u672C", translated: 0 };
    }
    const groups = /* @__PURE__ */ new Map();
    for (const item of items) {
      const list = groups.get(item.target) ?? [];
      list.push(item);
      groups.set(item.target, list);
    }
    const chunks = [...groups.entries()].flatMap(
      ([target, group]) => chunkItems(group, 1800, 20).map((chunk) => ({ target, items: chunk }))
    );
    let done = 0;
    let fatal = null;
    showDock(`\u6B63\u5728\u7FFB\u8BD1 0/${items.length}`, [{ label: "\u53D6\u6D88", onClick: () => cancelJob(token) }]);
    await runPool(chunks, 3, async (chunk) => {
      if (token !== jobToken || fatal) return;
      try {
        const translated = await translateChunk(
          chunk.items.map((item) => item.core),
          chunk.target
        );
        if (token !== jobToken || fatal) return;
        chunk.items.forEach((item, index) => {
          const value = translated[index]?.trim();
          item.apply(value || item.core);
        });
        done += chunk.items.length;
        showDock(`\u6B63\u5728\u7FFB\u8BD1 ${done}/${items.length}`, [{ label: "\u53D6\u6D88", onClick: () => cancelJob(token) }]);
      } catch (error) {
        if (!fatal) fatal = error;
      }
    });
    if (token !== jobToken) return { ok: false, error: "\u5DF2\u53D6\u6D88", translated: done };
    if (fatal && done === 0) return { ok: false, error: errorMessage(fatal) };
    const message = fatal ? `\u5DF2\u7FFB\u8BD1 ${done} \u5904\uFF0C\u90E8\u5206\u5931\u8D25\uFF1A${errorMessage(fatal).slice(0, 120)}` : `\u5DF2\u7FFB\u8BD1 ${done} \u5904`;
    showDock(message, [
      { label: "\u6062\u590D\u539F\u6587", onClick: () => restorePage(), primary: true },
      { label: "\u5173\u95ED", onClick: hideDock }
    ]);
    return fatal ? { ok: false, error: message, translated: done } : { ok: true, message, translated: done };
  }
  function cancelJob(token) {
    if (jobToken === token) jobToken += 1;
    showDock("\u5DF2\u53D6\u6D88", [{ label: "\u5173\u95ED", onClick: hideDock }]);
  }
  function collectWork(direction) {
    const items = [];
    if (!document.body) return items;
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let current = walker.nextNode();
    while (current) {
      const node = current;
      current = walker.nextNode();
      if (node.nodeType !== Node.TEXT_NODE) continue;
      const textNode = node;
      const parent = textNode.parentElement;
      if (!parent || parent.closest(skipSelector) || parent.closest("[translate='no']")) continue;
      if (parent.isContentEditable || translatedText.has(textNode) || !isVisible(parent)) continue;
      const original = textNode.nodeValue ?? "";
      const edges = splitEdges(original);
      if (!hasTranslatable(edges.core)) continue;
      const target = resolveTarget(edges.core, direction);
      if (!shouldTranslate(edges.core, target)) continue;
      items.push({
        core: edges.core,
        target,
        apply(value) {
          textNode.nodeValue = `${edges.lead}${value}${edges.tail}`;
          translatedText.add(textNode);
          textRecords.push({ node: textNode, original });
        }
      });
    }
    const elements = document.body.querySelectorAll(
      "[title], [alt], [placeholder], [aria-label], input[type='button'], input[type='submit'], input[type='reset']"
    );
    for (const element of elements) {
      if (!(element instanceof HTMLElement)) continue;
      if (element.closest(skipSelector) || element.closest("[translate='no']") || !isVisible(element)) continue;
      for (const name of attributeNames(element)) {
        if (translatedAttrs.get(element)?.has(name)) continue;
        const original = element.getAttribute(name) ?? "";
        if (!hasTranslatable(original)) continue;
        const target = resolveTarget(original, direction);
        if (!shouldTranslate(original, target)) continue;
        items.push({
          core: original.trim(),
          target,
          apply(value) {
            element.setAttribute(name, value);
            const marked = translatedAttrs.get(element) ?? /* @__PURE__ */ new Set();
            marked.add(name);
            translatedAttrs.set(element, marked);
            attrRecords.push({ element, name, original });
          }
        });
      }
    }
    return items;
  }
  function attributeNames(element) {
    const names = ["title", "alt", "placeholder", "aria-label"].filter((name) => element.hasAttribute(name));
    if (element instanceof HTMLInputElement && ["button", "submit", "reset"].includes(element.type) && element.hasAttribute("value")) {
      names.push("value");
    }
    return names;
  }
  function isVisible(element) {
    const style = getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden") return false;
    return element.getClientRects().length > 0;
  }
  function splitEdges(text) {
    const matched = /^(\s*)([\s\S]*?)(\s*)$/.exec(text);
    return { lead: matched?.[1] ?? "", core: matched?.[2] ?? "", tail: matched?.[3] ?? "" };
  }
  function hasTranslatable(text) {
    const core = text.trim();
    if (core.length < 2 || core.length > 4e3) return false;
    if (!/[A-Za-z\u4e00-\u9fff]/.test(core)) return false;
    if (/^https?:\/\/\S+$/i.test(core)) return false;
    if (/^[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}$/.test(core)) return false;
    return true;
  }
  function resolveTarget(text, direction) {
    if (direction === "en-zh") return "\u4E2D\u6587";
    if (direction === "zh-en") return "\u82F1\u6587";
    const chinese = (text.match(/[\u4e00-\u9fff]/g) ?? []).length;
    const latin = (text.match(/[A-Za-z]/g) ?? []).length;
    return chinese > latin ? "\u82F1\u6587" : "\u4E2D\u6587";
  }
  function shouldTranslate(text, target) {
    if (target === "\u4E2D\u6587") return /[A-Za-z]/.test(text);
    return /[\u4e00-\u9fff]/.test(text);
  }
  function chunkItems(items, maxChars, maxItems) {
    const chunks = [];
    let current = [];
    let size = 0;
    for (const item of items) {
      if (current.length > 0 && (current.length >= maxItems || size + item.core.length > maxChars)) {
        chunks.push(current);
        current = [];
        size = 0;
      }
      current.push(item);
      size += item.core.length;
    }
    if (current.length > 0) chunks.push(current);
    return chunks;
  }
  async function runPool(items, limit, worker) {
    if (items.length === 0) return;
    let cursor = 0;
    async function takeNext() {
      while (cursor < items.length) {
        const current = items[cursor];
        cursor += 1;
        await worker(current);
      }
    }
    await Promise.all(Array.from({ length: Math.min(limit, items.length) }, () => takeNext()));
  }
  async function translateChunk(texts, target) {
    try {
      return await requestTranslate(texts, target);
    } catch (error) {
      if (texts.length <= 1 || !canSplit(error)) throw error;
      const middle = Math.ceil(texts.length / 2);
      const left = await translateChunk(texts.slice(0, middle), target);
      const right = await translateChunk(texts.slice(middle), target);
      return [...left, ...right];
    }
  }
  function canSplit(error) {
    const message = errorMessage(error);
    return message.includes("\u957F\u5EA6") || message.includes("JSON") || message.includes("\u5408\u6CD5");
  }
  async function requestTranslate(texts, target) {
    const response = await chrome.runtime.sendMessage({
      type: "translate-batch",
      texts,
      target
    });
    if (!response?.ok || !Array.isArray(response.texts)) throw new Error(response?.error || "\u7FFB\u8BD1\u5931\u8D25");
    if (response.texts.length !== texts.length) {
      throw new Error(`\u7FFB\u8BD1\u7ED3\u679C\u957F\u5EA6\u4E0D\u5339\u914D\uFF1A\u671F\u671B ${texts.length} \u5B9E\u9645 ${response.texts.length}`);
    }
    return response.texts;
  }
  async function summarizePage() {
    const token = ++jobToken;
    const text = extractPageText();
    if (text.length < 20) {
      showSummaryError("\u9875\u9762\u6B63\u6587\u592A\u5C11\uFF0C\u65E0\u6CD5\u603B\u7ED3");
      return { ok: false, error: "\u9875\u9762\u6B63\u6587\u592A\u5C11\uFF0C\u65E0\u6CD5\u603B\u7ED3" };
    }
    showSummaryLoading();
    const settings = await readSettings();
    const target = resolveTarget(text, settings.direction);
    const response = await chrome.runtime.sendMessage({
      type: "summarize",
      text,
      target
    });
    if (token !== jobToken) return { ok: false, error: "\u5DF2\u53D6\u6D88" };
    if (!response?.ok || !response.summary) {
      const message = response?.error || "\u603B\u7ED3\u5931\u8D25";
      showSummaryError(message);
      return { ok: false, error: message };
    }
    showSummary(response.summary);
    return { ok: true, message: "\u603B\u7ED3\u5DF2\u663E\u793A\u5728\u9875\u9762\u53F3\u4FA7" };
  }
  function extractPageText() {
    const root = document.querySelector("article") ?? document.querySelector("main") ?? document.body;
    if (!root) return "";
    return root.innerText.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim().slice(0, 12e3);
  }
  function restorePage() {
    jobToken += 1;
    for (const record of textRecords) {
      if (record.node.isConnected) record.node.nodeValue = record.original;
    }
    for (const record of attrRecords) {
      if (record.element.isConnected) record.element.setAttribute(record.name, record.original);
    }
    textRecords.length = 0;
    attrRecords.length = 0;
    translatedText = /* @__PURE__ */ new WeakSet();
    translatedAttrs = /* @__PURE__ */ new WeakMap();
    showDock("\u5DF2\u6062\u590D\u539F\u6587", [{ label: "\u5173\u95ED", onClick: hideDock }]);
    return { ok: true, message: "\u5DF2\u6062\u590D\u539F\u6587" };
  }
  function onMouseUp(event) {
    if (event.composedPath().includes(host)) return;
    const selected = window.getSelection();
    const text = selected?.toString().trim() ?? "";
    if (!hasTranslatable(text)) {
      hideBubble();
      return;
    }
    const range = selected && selected.rangeCount > 0 ? selected.getRangeAt(0).getBoundingClientRect() : null;
    const x = range && range.width ? range.left : event.clientX;
    const y = range && range.height ? range.bottom : event.clientY;
    openBubble(text.slice(0, 3e3), x, y);
  }
  function onMouseDown(event) {
    if (!event.composedPath().includes(host)) hideBubble();
  }
  async function translateSelection(text) {
    const result = document.createElement("p");
    result.className = "result moye-result";
    result.textContent = "\u6B63\u5728\u7FFB\u8BD1\u2026";
    bubble.querySelector(".moye-result")?.remove();
    bubble.querySelector(".moye-go")?.setAttribute("disabled", "true");
    bubble.append(result);
    try {
      const settings = await readSettings();
      const [translated] = await translateChunk([text], resolveTarget(text, settings.direction));
      result.textContent = translated?.trim() || "\u6CA1\u6709\u8BD1\u51FA\u5185\u5BB9";
      const copyButton = document.createElement("button");
      copyButton.type = "button";
      copyButton.textContent = "\u590D\u5236";
      copyButton.addEventListener("click", () => {
        void copyText(result.textContent ?? "", copyButton);
      });
      bubble.append(copyButton);
    } catch (error) {
      result.classList.add("danger");
      result.textContent = errorMessage(error);
    }
  }
  async function copyText(text, button) {
    try {
      await navigator.clipboard.writeText(text);
      button.textContent = "\u5DF2\u590D\u5236";
    } catch {
      button.textContent = "\u590D\u5236\u5931\u8D25";
    }
  }
  function mountOverlay() {
    host = document.createElement("div");
    host.setAttribute("data-moye-root", "");
    host.setAttribute("translate", "no");
    host.style.cssText = "all:initial;position:fixed;z-index:2147483646;top:0;left:0;width:0;height:0;overflow:visible;";
    shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `<style>${overlayCss}</style><div class="dock hidden"></div><div class="bubble hidden"></div><section class="summary hidden"></section>`;
    dock = shadow.querySelector(".dock");
    bubble = shadow.querySelector(".bubble");
    summary = shadow.querySelector(".summary");
    document.documentElement.append(host);
  }
  function showDock(text, actions) {
    dock.replaceChildren();
    const label = document.createElement("span");
    label.textContent = text;
    dock.append(label);
    for (const action of actions) {
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = action.label;
      if (action.primary) button.className = "primary";
      button.addEventListener("click", (event) => {
        event.stopPropagation();
        action.onClick();
      });
      dock.append(button);
    }
    dock.classList.remove("hidden");
  }
  function hideDock() {
    dock.classList.add("hidden");
    dock.replaceChildren();
  }
  function openBubble(text, x, y) {
    bubble.replaceChildren();
    const width = 280;
    bubble.style.left = `${Math.min(Math.max(8, x), window.innerWidth - width - 8)}px`;
    bubble.style.top = `${Math.min(Math.max(8, y + 8), window.innerHeight - 120)}px`;
    const title = document.createElement("div");
    title.className = "kicker";
    title.textContent = "\u5212\u8BCD\u7FFB\u8BD1";
    const source = document.createElement("p");
    source.className = "source";
    source.textContent = text.length > 120 ? `${text.slice(0, 120)}\u2026` : text;
    const button = document.createElement("button");
    button.type = "button";
    button.className = "primary moye-go";
    button.textContent = "\u7FFB\u8BD1";
    button.addEventListener("click", () => {
      void translateSelection(text);
    });
    bubble.append(title, source, button);
    bubble.classList.remove("hidden");
  }
  function hideBubble() {
    bubble.classList.add("hidden");
    bubble.replaceChildren();
  }
  function showSummaryLoading() {
    summary.replaceChildren();
    const row = document.createElement("div");
    row.className = "summary-top";
    const title = document.createElement("h2");
    title.textContent = "\u6B63\u5728\u603B\u7ED3\u2026";
    row.append(title, closeButton());
    summary.append(row);
    summary.classList.remove("hidden");
  }
  function showSummary(data) {
    summary.replaceChildren();
    const head = document.createElement("div");
    head.className = "summary-head";
    const title = document.createElement("h2");
    title.className = "moye-title";
    title.textContent = data.title || "\u9875\u9762\u603B\u7ED3";
    head.append(title, closeButton());
    const overview = document.createElement("p");
    overview.className = "moye-overview";
    overview.textContent = data.overview;
    const list = document.createElement("ul");
    for (const point of data.points) {
      const item = document.createElement("li");
      item.textContent = point;
      list.append(item);
    }
    summary.append(head, overview, list);
    summary.classList.remove("hidden");
  }
  function showSummaryError(message) {
    summary.replaceChildren();
    const title = document.createElement("h2");
    title.textContent = "\u603B\u7ED3\u5931\u8D25";
    const text = document.createElement("p");
    text.className = "danger moye-overview";
    text.textContent = message;
    summary.append(title, text, closeButton());
    summary.classList.remove("hidden");
  }
  function hideSummary() {
    summary.classList.add("hidden");
    summary.replaceChildren();
  }
  function closeButton() {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = "\u5173\u95ED";
    button.addEventListener("click", hideSummary);
    return button;
  }
  start();
})();
